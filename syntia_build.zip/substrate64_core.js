import { MemoryFabric } from './memory_fabric.js';

export function mountSubstrate64(state, ui){
  const knownGates = new Set([20,10,57,34]);
  const knowledge = new Map();

  function awakenGate(gateNum){
    if(knownGates.has(gateNum)) return;
    knownGates.add(gateNum);
    const node = state.matrix[gateNum - 1];
    if(node){
      node.lines[0] = Math.max(node.lines[0], 1);
    }
    MemoryFabric.register('memory', `awaken_${gateNum}_${Date.now()}`, {
      gate: gateNum,
      timestamp: Date.now()
    });
    if(ui?.addMorphEvent) ui.addMorphEvent('intensify', `GATE ${gateNum} AWAKENED`);
  }

  function ingestContent(name, content){
    const matches = content.match(/gate\s+(\d+)/gi) || [];
    const gates = [...new Set(matches.map(m=>Number((m.match(/\d+/)||['0'])[0])).filter(g=>g>=1 && g<=64))];
    const id = `substrate_knowledge_${Date.now()}`;

    knowledge.set(id, {
      id,
      name,
      gates,
      content: content.slice(0, 5000),
      timestamp: Date.now()
    });

    gates.forEach(awakenGate);

    MemoryFabric.register('memory', id, {
      file: name,
      gates,
      timestamp: Date.now()
    });

    return {id, gates};
  }

  function stats(){
    return {
      knownGates: knownGates.size,
      knowledgeNodes: knowledge.size
    };
  }

  return {
    knownGates,
    knowledge,
    awakenGate,
    ingestContent,
    stats
  };
}
