import { MemoryFabric } from './memory_fabric.js';
import { LibraryStore } from './library_store.js';

export function createIngestBridge(runtime, ui, state){
  return {
    async ingestFiles(fileList){
      const files = Array.from(fileList || []);
      for(const file of files){
        await this.ingestFile(file);
      }
    },

    async ingestFile(file){
      let content = '';
      if(file.size < 1024 * 1024 * 3){
        try {
          content = await file.text();
        } catch {
          content = '';
        }
      }

      const result = LibraryStore.ingest(file.name, content, file.size);
      state.files.push({
        name: file.name,
        size: file.size,
        address: result.address,
        gate: result.structure.gate,
        type: result.structure.type
      });

      runtime.activateGate(result.structure.gate, result.structure.lineVector);
      const graphNode = runtime.spawnGraphNode(
        result.structure.gate,
        inferBehavior(result.structure.type)
      );

      MemoryFabric.register('input', `file_${Date.now()}`, {
        name: file.name,
        size: file.size,
        address: result.address,
        gate: result.structure.gate,
        type: result.structure.type,
        graphNodeId: graphNode?.id || null,
        timestamp: Date.now()
      });

      MemoryFabric.persist();

      if(ui?.addFileItem){
        ui.addFileItem({
          name: file.name,
          address: result.address,
          type: result.structure.type
        });
      }

      if(ui?.addMorphEvent){
        ui.addMorphEvent('spawn', `${file.name} → ${result.address}`);
      }

      if(ui?.addLog){
        ui.addLog(`INGEST ${file.name} -> ${result.address}`);
      }

      return result;
    }
  };
}

function inferBehavior(type){
  if(type === 'code') return 'active';
  if(type === 'data') return 'resonating';
  if(type === 'presentation') return 'transforming';
  if(type === 'document') return 'integrating';
  return 'receiving';
}
