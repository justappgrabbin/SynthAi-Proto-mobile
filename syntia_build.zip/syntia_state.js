export const HEXAGRAMS = [
  "Creative","Receptive","Difficulty","Youth","Waiting","Conflict","Army","Union",
  "Small Taming","Treading","Peace","Standstill","Fellowship","Great Possession",
  "Modesty","Enthusiasm","Following","Work on Decay","Approach","Contemplation",
  "Biting Through","Grace","Splitting","Return","Innocence","Taming Power",
  "Nourishment","Great Preponderance","Abysmal","Clinging","Influence","Duration",
  "Retreat","Great Power","Progress","Darkening","Family","Opposition","Obstruction",
  "Deliverance","Decrease","Increase","Breakthrough","Coming to Meet","Gathering",
  "Pushing Upward","Oppression","Well","Revolution","Cauldron","Shock","Keeping Still",
  "Development","Marrying Maiden","Abundance","Wanderer","Gentle","Joyous","Dispersing",
  "Limitation","Inner Truth","Small Preponderance","After Completion","Before Completion"
];

export const GATE_TO_CENTER = {
  64:"Head",61:"Head",63:"Head",
  47:"Ajna",24:"Ajna",4:"Ajna",11:"Ajna",17:"Ajna",43:"Ajna",
  62:"Throat",23:"Throat",56:"Throat",35:"Throat",12:"Throat",45:"Throat",33:"Throat",20:"Throat",31:"Throat",8:"Throat",16:"Throat",
  1:"G",13:"G",10:"G",25:"G",15:"G",46:"G",7:"G",2:"G",
  21:"Heart",40:"Heart",51:"Heart",26:"Heart",
  55:"Solar",30:"Solar",49:"Solar",37:"Solar",36:"Solar",22:"Solar",6:"Solar",
  50:"Spleen",32:"Spleen",28:"Spleen",57:"Spleen",18:"Spleen",48:"Spleen",44:"Spleen",
  34:"Sacral",5:"Sacral",14:"Sacral",29:"Sacral",59:"Sacral",27:"Sacral",42:"Sacral",3:"Sacral",9:"Sacral",
  19:"Root",41:"Root",60:"Root",52:"Root",53:"Root",54:"Root",38:"Root",58:"Root",39:"Root"
};

export const CENTER_COLOR = {
  Head:"#a259ff",Ajna:"#7c3aed",Throat:"#00ffb4",G:"#ffcc00",
  Heart:"#ff2d78",Solar:"#ff6600",Spleen:"#00c4ff",Sacral:"#ff3388",Root:"#888"
};

export const COLORS = {
  1:{name:"Caves",motivation:"Need"},
  2:{name:"Markets",motivation:"Guilt"},
  3:{name:"Kitchens",motivation:"Uncertainty"},
  4:{name:"Mountains",motivation:"Action"},
  5:{name:"Valleys",motivation:"Hope"},
  6:{name:"Shores",motivation:"Peace"}
};

export const TONES = {
  1:{name:"Active",gnn:"spatial"},
  2:{name:"Receptive",gnn:"temporal"},
  3:{name:"Strategic",gnn:"attention"},
  4:{name:"Observed",gnn:"diffusion"},
  5:{name:"Focused",gnn:"hierarchical"},
  6:{name:"Peripheral",gnn:"integration"}
};

export const BASES = {
  1:{name:"Left",gnn:"spatial"},
  2:{name:"Right",gnn:"temporal"},
  3:{name:"Solar",gnn:"attention"},
  4:{name:"Lunar",gnn:"diffusion"},
  5:{name:"Terrestrial",gnn:"hierarchical"}
};

export function createState(){
  return {
    matrix: Array.from({length:64}, (_,i)=>({
      gate:i+1,
      lines:[0,0,0,0,0,0],
      selected:false
    })),
    nodes: [],
    edges: [],
    files: [],
    morphHistory: [],
    morphCount: 0,
    structuralTension: 0,
    geometry: "linear",
    selectedGate: 19,
    layers: {
      text: 0.2,
      nav: 0.3,
      temporal: 0.5,
      celestial: 0.4,
      resonance: 0.15
    },
    address: {
      d: 2,
      gate: 20,
      line: 1,
      color: 1,
      tone: 1,
      base: 1,
      planet: "Sun",
      circuit: "Integration",
      pressure: 0.30
    },
    hexagrams: HEXAGRAMS,
    gateToCenter: (gate)=>GATE_TO_CENTER[gate] || "Unknown",
    currentAddressString(){
      const a = this.address;
      return `D${a.d}·G${a.gate}·L${a.line}·C${a.color}·T${a.tone}·B${a.base}`;
    }
  };
}
