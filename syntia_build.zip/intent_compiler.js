import { MemoryFabric } from './memory_fabric.js';
export function hashStr(str){ let h=0; for(let i=0;i<str.length;i++){ h=((h<<5)-h+str.charCodeAt(i))|0; } return Math.abs(h); }
export function extractIntentTraits(text){ const t=text.toLowerCase(); return {
  build:/\b(build|system|admin|panel|router|hook|wire|deploy|structure)\b/.test(t),
  morph:/\b(morph|transform|change|shift|mutate|evolve|reshape)\b/.test(t),
  destroy:/\b(delete|remove|clear|destroy|dissolve|stop|end)\b/.test(t),
  expand:/\b(expand|grow|scale|increase|extend|branch)\b/.test(t),
  compress:/\b(compress|reduce|minimize|condense|simplify)\b/.test(t),
  study:/\b(study|learn|read|inspect|analyze|ingest|understand)\b/.test(t),
  browser:/\b(browser|browse|web|internet|page|site)\b/.test(t),
  chat:/\b(chat|talk|message|speak|discuss|cynthia)\b/.test(t),
  library:/\b(library|book|books|document|manual|archive|storage)\b/.test(t),
  intensity:Math.min(1, Math.max(0.15, text.length/140))
};}
export function deriveAddressFromIntent(text){
  const traits=extractIntentTraits(text); const gate=(hashStr(text)%64)+1;
  const vector=[traits.build?1:0, traits.morph?1:0, traits.expand?1:0, traits.compress?1:0, traits.study?1:0, traits.intensity];
  const line=vector.indexOf(Math.max(...vector))+1; const color=((line-1)%6)+1; const tone=((color-1)%6)+1; const base=((tone-1)%5)+1; const dimension=Math.ceil(gate/13);
  return {dimension,gate,line,color,tone,base,traits,vector,address:`D${dimension}·G${gate}·L${line}·C${color}·T${tone}·B${base}`};
}
export function compileIntent(text, runtime){
  const intentNode=createIntentNode(text); const compiled=deriveAddressFromIntent(text); const gateNode=createGateNode(compiled); MemoryFabric.link(intentNode.id, gateNode.id);
  if(runtime?.activateGate) runtime.activateGate(compiled.gate, compiled.vector);
  if(runtime?.spawnGraphNode){ const graphNode=runtime.spawnGraphNode(compiled.gate, selectBehavior(compiled.traits)); if(graphNode?.id){ MemoryFabric.register('graph', graphNode.id, graphNode); MemoryFabric.link(gateNode.id, graphNode.id); } }
  const morphNode=createMorphNode(compiled); MemoryFabric.link(gateNode.id, morphNode.id); MemoryFabric.history.push(morphNode.id); MemoryFabric.persist(); return compiled;
}
export function selectBehavior(traits){ if(traits.destroy) return 'dispersing'; if(traits.morph) return 'transforming'; if(traits.expand) return 'resonating'; if(traits.build) return 'active'; if(traits.study) return 'integrating'; return 'receiving'; }
function createIntentNode(text){ const id=`intent_${Date.now()}_${Math.random().toString(36).slice(2,6)}`; const node={id,type:'intent',data:{text},refs:[],timestamp:Date.now()}; MemoryFabric.register('input', id, node); return node; }
function createGateNode(compiled){ const id=`gate_${compiled.gate}_${Date.now()}_${Math.random().toString(36).slice(2,6)}`; const node={id,type:'gate',data:{gate:compiled.gate,line:compiled.line,color:compiled.color,tone:compiled.tone,base:compiled.base,address:compiled.address},refs:[],timestamp:Date.now()}; MemoryFabric.register('address', id, node); return node; }
function createMorphNode(compiled){ const id=`morph_${Date.now()}_${Math.random().toString(36).slice(2,6)}`; const node={id,type:'morph',data:compiled,refs:[],timestamp:Date.now()}; MemoryFabric.register('morph', id, node); return node; }
