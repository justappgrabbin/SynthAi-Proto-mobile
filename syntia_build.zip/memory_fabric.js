export const MemoryFabric = {
  core: {}, input: {}, memory: {}, graph: {}, address: {}, morph: {}, output: {},
  links: [], history: [],
  register(layer, key, value){ if(!this[layer]) this[layer]={}; this[layer][key]=value; this.trace(layer,key); },
  get(layer,key){ return this[layer]?.[key]; },
  trace(layer,key){ this.links.push({layer,key,time:Date.now()}); },
  link(a,b){ this.links.push({from:a,to:b,time:Date.now()}); },
  persist(){ localStorage.setItem('MF_STATE', JSON.stringify(this)); },
  load(){ const data=localStorage.getItem('MF_STATE'); if(data){ const parsed=JSON.parse(data); Object.assign(this, parsed); } }
};
